from grievance.grievance_manager import GrievanceManager, STATUSES
from analytics.analyzer import Analytics
from analytics.visualization import Visualizer

ADMIN_PASSWORD = "admin123"


def print_statuses() -> None:
    print("\nAvailable Statuses:")
    for index, status in enumerate(STATUSES, start=1):
        print(f"{index}. {status}")


def admin_menu(manager: GrievanceManager) -> None:
    password = input("Enter admin password: ").strip()
    if password != ADMIN_PASSWORD:
        print("Incorrect password.")
        return

    analytics = Analytics(manager.grievance_file)
    visualizer = Visualizer(manager.grievance_file)

    while True:
        print("\n===== ADMIN DASHBOARD =====")
        print("1. View all grievances")
        print("2. Search grievance by ID")
        print("3. Update grievance status")
        print("4. View grievance logs")
        print("5. Show analytics summary")
        print("6. Generate charts")
        print("7. Back to main menu")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            grievances = manager.list_all_grievances()
            if not grievances:
                print("No grievances found.")
                continue
            for grievance in grievances:
                print("\n-------------------------------")
                print("Grievance ID      :", grievance.grievance_id)
                print("Student Name      :", grievance.student_name)
                print("Registration No   :", grievance.reg_no)
                print("Category          :", grievance.category)
                print("Status            :", grievance.status)
                print("Priority          :", grievance.priority)
                print("Assigned Authority:", grievance.assigned_authority)
                print("Submission Date   :", grievance.submission_date)
                print("Remarks           :", grievance.remarks or "No remarks")

        elif choice == "2":
            grievance_id = input("Enter grievance ID: ").strip()
            grievance = manager.find_by_id(grievance_id)
            if grievance is None:
                print("Grievance not found.")
            else:
                print("\nGrievance ID      :", grievance.grievance_id)
                print("Student Name      :", grievance.student_name)
                print("Registration No   :", grievance.reg_no)
                print("Category          :", grievance.category)
                print("Description       :", grievance.description)
                print("Submission Date   :", grievance.submission_date)
                print("Assigned Authority:", grievance.assigned_authority)
                print("Status            :", grievance.status)
                print("Priority          :", grievance.priority)
                print("Remarks           :", grievance.remarks or "No remarks")
                print("Resolution Date   :", grievance.resolution_date or "Not resolved yet")

        elif choice == "3":
            grievance_id = input("Enter grievance ID: ").strip()
            print_statuses()
            try:
                status_index = int(input("Choose new status number: ")) - 1
                new_status = STATUSES[status_index]
            except (ValueError, IndexError):
                print("Invalid status selected.")
                continue

            assigned_authority = input("Enter assigned authority/committee: ").strip()
            remarks = input("Enter remarks: ").strip()

            try:
                updated = manager.update_grievance(
                    grievance_id=grievance_id,
                    new_status=new_status,
                    assigned_authority=assigned_authority,
                    remarks=remarks,
                    performed_by="Admin",
                )
                print("Grievance updated successfully." if updated else "Grievance not found.")
            except ValueError as error:
                print(error)

        elif choice == "4":
            grievance_id = input("Enter grievance ID: ").strip()
            logs = manager.get_logs(grievance_id)
            if not logs:
                print("No logs found for this grievance ID.")
            else:
                for log in logs:
                    print(f"{log['date']} | {log['performed_by']} | {log['action']}")

        elif choice == "5":
            analytics.show_summary()

        elif choice == "6":
            visualizer.generate_charts()

        elif choice == "7":
            break

        else:
            print("Invalid choice. Please try again.")
