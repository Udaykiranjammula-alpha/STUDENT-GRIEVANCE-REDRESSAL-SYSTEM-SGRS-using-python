import numpy as np
import pandas as pd
from grievance.grievance_manager import GRIEVANCE_FILE


class Analytics:
    def __init__(self, grievance_file: str = GRIEVANCE_FILE):
        self.grievance_file = grievance_file

    def _load_dataframe(self):
        df = pd.read_csv(self.grievance_file)
        if df.empty:
            return df
        df["submission_date"] = pd.to_datetime(df["submission_date"], errors="coerce")
        df["resolution_date"] = pd.to_datetime(df["resolution_date"], errors="coerce")
        return df

    def show_summary(self) -> None:
        df = self._load_dataframe()
        if df.empty:
            print("No grievance data available for analysis.")
            return

        print("\n===== ANALYTICS SUMMARY =====")
        print("Total grievances:", len(df))
        print("Pending grievances:", int((~df["status"].isin(["Resolved", "Rejected"])).sum()))
        print("Resolved grievances:", int((df["status"] == "Resolved").sum()))
        print("Rejected grievances:", int((df["status"] == "Rejected").sum()))

        print("\nCategory-wise grievance count:")
        print(df["category"].value_counts().to_string())

        resolved_df = df.dropna(subset=["submission_date", "resolution_date"]).copy()
        if not resolved_df.empty:
            resolution_days = (
                resolved_df["resolution_date"] - resolved_df["submission_date"]
            ).dt.total_seconds() / (24 * 3600)
            print(f"\nAverage resolution time: {np.mean(resolution_days):.2f} days")
        else:
            print("\nAverage resolution time: Not enough resolved data")

        df["month"] = df["submission_date"].dt.to_period("M").astype(str)
        print("\nMonthly grievance trends:")
        print(df["month"].value_counts().sort_index().to_string())
