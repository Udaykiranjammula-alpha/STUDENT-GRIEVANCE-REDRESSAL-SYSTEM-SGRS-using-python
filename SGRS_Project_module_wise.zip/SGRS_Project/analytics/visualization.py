import os
import matplotlib.pyplot as plt
from analytics.analyzer import Analytics
from grievance.grievance_manager import DATA_DIR, GRIEVANCE_FILE


class Visualizer:
    def __init__(self, grievance_file: str = GRIEVANCE_FILE):
        self.analytics = Analytics(grievance_file)

    def generate_charts(self) -> None:
        df = self.analytics._load_dataframe()
        if df.empty:
            print("No grievance data available to generate charts.")
            return

        category_chart = os.path.join(DATA_DIR, "category_chart.png")
        status_chart = os.path.join(DATA_DIR, "status_pie_chart.png")
        monthly_chart = os.path.join(DATA_DIR, "monthly_trend_chart.png")

        category_counts = df["category"].value_counts()
        plt.figure(figsize=(8, 5))
        category_counts.plot(kind="bar")
        plt.title("Number of Grievances per Category")
        plt.xlabel("Category")
        plt.ylabel("Count")
        plt.tight_layout()
        plt.savefig(category_chart)
        plt.close()

        status_counts = df["status"].value_counts()
        plt.figure(figsize=(7, 7))
        status_counts.plot(kind="pie", autopct="%1.1f%%")
        plt.title("Grievance Status Distribution")
        plt.ylabel("")
        plt.tight_layout()
        plt.savefig(status_chart)
        plt.close()

        df["month"] = df["submission_date"].dt.to_period("M").astype(str)
        monthly_counts = df.groupby("month").size()
        plt.figure(figsize=(8, 5))
        monthly_counts.plot(kind="line", marker="o")
        plt.title("Monthly Grievance Submission Trends")
        plt.xlabel("Month")
        plt.ylabel("Number of Grievances")
        plt.tight_layout()
        plt.savefig(monthly_chart)
        plt.close()

        print("Charts generated successfully:")
        print(f"- {category_chart}")
        print(f"- {status_chart}")
        print(f"- {monthly_chart}")
