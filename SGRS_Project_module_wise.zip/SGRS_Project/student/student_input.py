from grievance.grievance_manager import CATEGORIES, GrievanceManager


def print_categories() -> None:
    print("\nAvailable Categories:")
    for index, category in enumerate(CATEGORIES, start=1):
        print(f"{index}. {category}")


def submit_flow(manager: GrievanceManager) -> None:
    print("\n===== SUBMIT GRIEVANCE =====")
    student_name = input("Enter student name: ").strip()
    reg_no = input("Enter registration number: ").strip()
    print_categories()

    try:
        category_index = int(input("Choose category number: ")) - 1
        category = CATEGORIES[category_index]
    except (ValueError, IndexError):
        category = "Others"
        print("Invalid category. 'Others' selected.")

    description = input("Enter grievance description: ").strip()
    priority = input("Enter priority (Low/Medium/High): ").strip().title() or "Medium"
    document_path = input("Enter supporting document path (optional): ").strip()

    if not student_name or not reg_no or not description:
        print("Student name, registration number, and description are required.")
        return

    grievance_id = manager.submit_grievance(
        student_name=student_name,
        reg_no=reg_no,
        category=category,
        description=description,
        priority=priority,
        document_path=document_path,
    )
    print(f"Grievance submitted successfully. Your Grievance ID is: {grievance_id}")


def student_tracking_flow(manager: GrievanceManager) -> None:
    print("\n===== TRACK MY GRIEVANCES =====")
    reg_no = input("Enter your registration number: ").strip()
    grievances = manager.find_by_reg_no(reg_no)

    if not grievances:
        print("No grievances found for this registration number.")
        return

    for grievance in grievances:
        print("\n-------------------------------")
        print("Grievance ID      :", grievance.grievance_id)
        print("Category          :", grievance.category)
        print("Description       :", grievance.description)
        print("Submission Date   :", grievance.submission_date)
        print("Assigned Authority:", grievance.assigned_authority)
        print("Status            :", grievance.status)
        print("Priority          :", grievance.priority)
        print("Remarks           :", grievance.remarks or "No remarks")
        print("Resolution Date   :", grievance.resolution_date or "Not resolved yet")
