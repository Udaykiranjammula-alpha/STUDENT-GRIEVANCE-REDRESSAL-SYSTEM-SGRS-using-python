from grievance.grievance_manager import GrievanceManager
from student.student_input import submit_flow, student_tracking_flow
from admin.admin_actions import admin_menu


def main() -> None:
    manager = GrievanceManager()

    while True:
        print("\n===== STUDENT GRIEVANCE REDRESSAL SYSTEM =====")
        print("1. Submit grievance")
        print("2. Track my grievances")
        print("3. Admin dashboard")
        print("4. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            submit_flow(manager)
        elif choice == "2":
            student_tracking_flow(manager)
        elif choice == "3":
            admin_menu(manager)
        elif choice == "4":
            print("Thank you for using SGRS.")
            break
        else:
            print("Invalid choice. Please enter 1, 2, 3, or 4.")


if __name__ == "__main__":
    main()
