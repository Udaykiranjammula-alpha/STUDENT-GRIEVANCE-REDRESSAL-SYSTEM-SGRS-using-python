import csv
import os
import uuid
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

GRIEVANCE_FILE = os.path.join(DATA_DIR, "grievances.csv")
LOG_FILE = os.path.join(DATA_DIR, "grievance_logs.csv")
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
CATEGORIES = [
    "Academic",
    "Examination",
    "Hostel",
    "Transport",
    "Administration",
    "Others",
]
STATUSES = ["Submitted", "Under Review", "In Process", "Resolved", "Rejected"]


@dataclass
class Grievance:
    grievance_id: str
    student_name: str
    reg_no: str
    category: str
    description: str
    submission_date: str
    assigned_authority: str = "Not Assigned"
    status: str = "Submitted"
    remarks: str = ""
    priority: str = "Medium"
    resolution_date: str = ""
    document_path: str = ""

    def to_dict(self) -> Dict[str, str]:
        return asdict(self)

    @staticmethod
    def from_dict(row: Dict[str, str]) -> "Grievance":
        return Grievance(
            grievance_id=row.get("grievance_id", ""),
            student_name=row.get("student_name", ""),
            reg_no=row.get("reg_no", ""),
            category=row.get("category", "Others"),
            description=row.get("description", ""),
            submission_date=row.get("submission_date", ""),
            assigned_authority=row.get("assigned_authority", "Not Assigned"),
            status=row.get("status", "Submitted"),
            remarks=row.get("remarks", ""),
            priority=row.get("priority", "Medium"),
            resolution_date=row.get("resolution_date", ""),
            document_path=row.get("document_path", ""),
        )


class GrievanceManager:
    grievance_headers = [
        "grievance_id",
        "student_name",
        "reg_no",
        "category",
        "description",
        "submission_date",
        "assigned_authority",
        "status",
        "remarks",
        "priority",
        "resolution_date",
        "document_path",
    ]
    log_headers = ["grievance_id", "action", "date", "performed_by"]

    def __init__(self, grievance_file: str = GRIEVANCE_FILE, log_file: str = LOG_FILE):
        self.grievance_file = grievance_file
        self.log_file = log_file
        self._ensure_files()

    def _ensure_files(self) -> None:
        if not os.path.exists(self.grievance_file):
            with open(self.grievance_file, "w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, fieldnames=self.grievance_headers)
                writer.writeheader()
        if not os.path.exists(self.log_file):
            with open(self.log_file, "w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, fieldnames=self.log_headers)
                writer.writeheader()

    def _generate_id(self) -> str:
        return "GRV-" + uuid.uuid4().hex[:8].upper()

    def _current_time(self) -> str:
        return datetime.now().strftime(DATE_FORMAT)

    def _read_all(self) -> List[Grievance]:
        grievances: List[Grievance] = []
        with open(self.grievance_file, "r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            for row in reader:
                grievances.append(Grievance.from_dict(row))
        return grievances

    def _write_all(self, grievances: List[Grievance]) -> None:
        with open(self.grievance_file, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=self.grievance_headers)
            writer.writeheader()
            for grievance in grievances:
                writer.writerow(grievance.to_dict())

    def _add_log(self, grievance_id: str, action: str, performed_by: str) -> None:
        with open(self.log_file, "a", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=self.log_headers)
            writer.writerow(
                {
                    "grievance_id": grievance_id,
                    "action": action,
                    "date": self._current_time(),
                    "performed_by": performed_by,
                }
            )

    def submit_grievance(
        self,
        student_name: str,
        reg_no: str,
        category: str,
        description: str,
        priority: str = "Medium",
        document_path: str = "",
    ) -> str:
        grievance_id = self._generate_id()
        grievance = Grievance(
            grievance_id=grievance_id,
            student_name=student_name.strip(),
            reg_no=reg_no.strip(),
            category=category if category in CATEGORIES else "Others",
            description=description.strip(),
            submission_date=self._current_time(),
            priority=priority.strip().title() if priority else "Medium",
            document_path=document_path.strip(),
        )
        with open(self.grievance_file, "a", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=self.grievance_headers)
            writer.writerow(grievance.to_dict())
        self._add_log(grievance_id, "Grievance submitted", reg_no)
        return grievance_id

    def list_all_grievances(self) -> List[Grievance]:
        return self._read_all()

    def find_by_id(self, grievance_id: str) -> Optional[Grievance]:
        grievance_id = grievance_id.strip().upper()
        for grievance in self._read_all():
            if grievance.grievance_id.upper() == grievance_id:
                return grievance
        return None

    def find_by_reg_no(self, reg_no: str) -> List[Grievance]:
        reg_no = reg_no.strip()
        return [g for g in self._read_all() if g.reg_no == reg_no]

    def update_grievance(
        self,
        grievance_id: str,
        new_status: Optional[str] = None,
        assigned_authority: Optional[str] = None,
        remarks: Optional[str] = None,
        performed_by: str = "Admin",
    ) -> bool:
        grievances = self._read_all()
        grievance_id = grievance_id.strip().upper()
        updated = False

        for grievance in grievances:
            if grievance.grievance_id.upper() == grievance_id:
                if new_status:
                    if new_status not in STATUSES:
                        raise ValueError("Invalid status selected.")
                    grievance.status = new_status
                    if new_status in ("Resolved", "Rejected"):
                        grievance.resolution_date = self._current_time()
                if assigned_authority is not None and assigned_authority.strip():
                    grievance.assigned_authority = assigned_authority.strip()
                if remarks is not None:
                    grievance.remarks = remarks.strip()
                updated = True
                break

        if updated:
            self._write_all(grievances)
            action = f"Updated: {new_status}" if new_status else "Details updated"
            self._add_log(grievance_id, action, performed_by)
        return updated

    def get_logs(self, grievance_id: str) -> List[Dict[str, str]]:
        logs: List[Dict[str, str]] = []
        grievance_id = grievance_id.strip().upper()
        with open(self.log_file, "r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row.get("grievance_id", "").upper() == grievance_id:
                    logs.append(row)
        return logs
